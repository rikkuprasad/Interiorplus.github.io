Hi!

To use the php contact form, edit the file contact-form/config.php.

To enable reCaptcha for the contact form (it will work if you don't configure it), access the reCaptcha admin console at
https://www.google.com/recaptcha/admin and create a new site. Then edit the files contact-form/config.php to set the secret key and
js/script.js to set the site key.

Don't hesitate to contact me if you have any questions or problems.

Thank you very much!
