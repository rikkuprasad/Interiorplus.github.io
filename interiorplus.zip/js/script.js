/**
 * Copyright, 2021, Gabriel Quagliano, gabriel.quagliano@gmail.com
 */


//// To enable reCaptcha for the contact form, set your site key below (it will work without it if you leave this
//// blank, but don't remove the following line)
var _recaptchaSiteKey="";
////////


$(function(){
	"use strict";
	if(_recaptchaSiteKey) recaptcha.preparar(_recaptchaSiteKey);
	var contactOpen=false,
	sendingForm=false,
	openContact=function() {
		$("#shadow").stop().show().fadeTo(300,1);
		$("#contact-form").stop().css("display","flex").animate({ opacity:1,zoom:1 },300,function() {
			$("#contact-form :input").first().focus();
		});
		$("body").addClass("overflow-hidden");
		contactOpen=true;
	},
	closeContact=function() {
		contactOpen=false;
		$("#shadow,#contact-form").stop().fadeTo(200,0,function() {
			$(this).hide();
			$("#contact-form").removeAttr("style");
		});
		$("body").removeClass("overflow-hidden");
	},
	submitForm=function(elem) {
		if(sendingForm) return;
		sendingForm=true;
		var form=$(elem).parents("form"),
			btn=form.find(".btn-primary"),
			responseElem=form.find(".response");
		btn.prop("disabled",true);
		var fn=function() {
			$.post("contact-form/send.php",form.serialize(),function(resp) {
				resp=JSON.parse(resp);
				if(resp.status=="ok") form.get(0).reset();
				form.find(".response").stop().html(resp.message).slideDown(200);
				btn.prop("disabled",false);
				sendingForm=false;
			});
		};
		responseElem.stop().slideUp(200,function() {
			if(_recaptchaSiteKey) {
				recaptcha.enviar(form.get(0),function(prueba) {
	            	if(prueba) fn();
	            });
			} else {
				fn();
			}
		});
	},
	processHash=function() {
		var hash=window.location.hash.substring(1),
			y=null;
		if(!hash) {
			y=0;
		} else if(hash=="contact-us") {
			openContact();
			return;
		} else {
			var elem=$("#"+hash);
			if(elem.length) y=elem.offset().top-100;
		}
		if(contactOpen) {
			closeContact();
			return;
		}
		if(y!==null) $("body,html").stop().animate({ scrollTop:y },800);
	};
	$(window).on("hashchange",function(ev) {
		ev.preventDefault();
		processHash();
	})
	.on("load",function() {
		processHash();
	});
	$("#contact-form input").on("keydown",function(ev) {
		if(ev.which==13) {
			ev.preventDefault();
			submitForm(this);
		}
	});
	window.closeContact=function() {
		window.location.hash="";
		closeContact();
	};
	window.submitForm=submitForm;
});