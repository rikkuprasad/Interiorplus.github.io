<?php
/**
 * Copyright, 2021, Gabriel Quagliano, gabriel.quagliano@gmail.com
 */


//// Contact form configuration

//Recipient
define('_recipient','your@email.com');

//reCaptcha (it will work without it if you leave this blank, but don't remove the following line)
define('_recaptcha_secret','');

//SMTP server (not required if your server supports the mail() function--in such case leave values blank, don't remove the following lines)
define('_smtp_host','');
define('_smtp_port',587);
define('_smtp_user','');
define('_smtp_password','');
