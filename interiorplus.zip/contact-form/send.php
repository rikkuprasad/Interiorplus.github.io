<?php
/**
 * Copyright, 2021, Gabriel Quagliano, gabriel.quagliano@gmail.com
 */

include(__DIR__.'/config.php');
include(__DIR__.'/class.phpmailer.php');
include(__DIR__.'/class.smtp.php');
include(__DIR__.'/recaptcha.php');

header('Content-Type: text/plain; charset=utf-8',true);

$data=(object)filter_input_array(INPUT_POST,[
	'name'=>FILTER_DEFAULT,
	'phone'=>FILTER_DEFAULT,
	'email'=>FILTER_VALIDATE_EMAIL,
	'message'=>FILTER_DEFAULT
]);

//if(_recaptcha_secret&&!\recaptcha::validarFormulario(_recaptcha_secret)) 
//	reply('error','reCaptcha validation failed. Please, reload the page and try again.');

if(!$data->name||!$data->phone) reply('error','Please, fill all the fields marked with *');
if(!$data->email) reply('error','Please, enter a valid email address.');

$mail=new PHPMailer(true);

$mail->AddReplyTo($data->email);
$mail->From=_recipient;
$mail->FromName=$name;

$to=explode(';',str_replace(',',';',_recipient));
foreach($to as $addr)
	if($addr) $mail->AddAddress($addr);

$mail->Subject='Message from InteriorPlus';
			
$mail->CharSet='UTF-8';

$body='<html><head><style>body,html{font-family:Verdana,Arial,sans-serif;font-size:14px;color:#333;}</style></head><body><p><strong>Name:</strong> '.h($data->name).
	'</p><p><strong>Phone no.:</strong> '.h($data->phone).'</p><p><strong>Email:</strong> '.h($data->email).'</p><p><strong>Message:</strong> '.nl2br(h($data->message)).'</p></body></html>';
			
$alt=html_entity_decode($body);
$alt=preg_replace('/<br[^>]*>/si',"\n",$alt);
$alt=preg_replace('/<hr[^>]*>/si',"\n----\n\n",$alt);
$alt=preg_replace('/<head>.*?<\/head>/si','',$alt);
$alt=strip_tags($alt);
$mail->AltBody=$alt;
		
$mail->MsgHTML($body);
$mail->IsHTML(true);

$mail->IsMail();

if(_smtp_host) {
	$mail->IsSMTP();
	$mail->SMTPDebug=1;
	$mail->Host=_smtp_host;
	$mail->SMTPAuth=true;
	$mail->Port=_smtp_port;
	$mail->SMTPSecure='';
	$mail->SMTPAutoTLS=false;
	$mail->Username=_smtp_user;
	$mail->Password=_smtp_password;
}
		
$mail->Send();

reply('ok','Your message has been sent. Thank you!');


function reply($status,$message) {
	echo json_encode(['status'=>$status,'message'=>$message]);
	exit;
}

function h($str) {
	return htmlentities($str,ENT_COMPAT,'utf-8');
}